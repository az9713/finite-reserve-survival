Candidate research draft; priority and independent review pending.
Build: tectonic manuscript.tex (or XeLaTeX, twice).
Fonts: standard Latin Modern supplied with TeX.
Human authorship and responsibility must be settled before submission.
Computational supplements are in the accompanying project package.
